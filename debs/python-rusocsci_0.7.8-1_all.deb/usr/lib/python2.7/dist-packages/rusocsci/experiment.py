#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
RuSocSci module for the BITSI buttonbox

Copyright (C) 2013-2015 Wilbert van Ham, Radboud University Nijmegen
Distributed under the terms of the GNU General Public License (GPL) version 3 or newer.
"""
import xml, sys, time

class Experiment(object):
	"""
	Experiment Handler
	"""
	
	
if __name__ == '__main__':
	exp = Experiment(sys.argv[1])